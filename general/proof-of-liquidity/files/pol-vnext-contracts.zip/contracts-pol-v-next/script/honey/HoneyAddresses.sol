// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import { ChainType } from "../base/Chain.sol";

struct HoneyAddresses {
    address honey;
    address honeyImpl;
    address honeyFactory;
    address honeyFactoryReader;
    address honeyFactoryImpl;
    address honeyFactoryReaderImpl;
    address collateralVaultImpl;
    address honeyFactoryPythWrapper;
}

abstract contract HoneyAddressBook {
    HoneyAddresses internal _honeyAddresses;

    constructor(ChainType chainType) {
        if (chainType == ChainType.Mainnet) {
            _honeyAddresses = _getMainnetHoneyAddresses();
        } else if (chainType == ChainType.Testnet) {
            _honeyAddresses = _getTestnetHoneyAddresses();
        } else if (chainType == ChainType.Devnet) {
            _honeyAddresses = _getDevnetHoneyAddresses();
        } else {
            _honeyAddresses = _getAnvilHoneyAddresses();
        }
    }

    /// @notice Mainnet addresses
    /// @dev Some of this contracts were deployed with a different context, hence their adddress should not be updated
    /// even if the predicted ones are different.
    function _getMainnetHoneyAddresses() private pure returns (HoneyAddresses memory) {
        return HoneyAddresses({
            honey: 0xFCBD14DC51f0A4d49d5E53C2E0950e0bC26d0Dce,
            honeyImpl: 0x96b1a552A97dA5503343d0F9FF2766c616E62905,
            honeyFactory: 0xA4aFef880F5cE1f63c9fb48F661E27F8B4216401,
            honeyFactoryReader: 0x285e147060CDc5ba902786d3A471224ee6cE0F91,
            honeyFactoryImpl: 0x6331F0a4E0220a14Be27BD31aF091F0a1AC036A1,
            honeyFactoryReaderImpl: 0x91C54526A9f8D0391F64392f24C7E8ff94A5f4fB,
            collateralVaultImpl: 0xAa4f2Bc7a06c89BEAB5125D82e25D4166b4a4681,
            honeyFactoryPythWrapper: 0xF5686e448BE103beA465105bEb9d284a34ae7e95
        });
    }

    /// @notice Bepolia addresses
    /// @dev Some of this contracts were deployed with a different context, hence their adddress should not be updated
    /// even if the predicted ones are different.
    function _getTestnetHoneyAddresses() private pure returns (HoneyAddresses memory) {
        return HoneyAddresses({
            honey: 0xFCBD14DC51f0A4d49d5E53C2E0950e0bC26d0Dce,
            honeyImpl: 0xD1886E0659Ed88812aeA75862Cc9891097c25542,
            honeyFactory: 0xA4aFef880F5cE1f63c9fb48F661E27F8B4216401,
            honeyFactoryReader: 0x285e147060CDc5ba902786d3A471224ee6cE0F91,
            honeyFactoryImpl: 0xD38a1fD3E943a61066903889b8e0889EcAc6Dedd,
            honeyFactoryReaderImpl: 0x22ee76216B1b7E4f34CF1417da3E4773F7cbA8E6,
            collateralVaultImpl: 0xE3689043e7F860FbC0c814839cd7dF5022223172,
            honeyFactoryPythWrapper: 0xE5Ad9BA751714ec8cdd554b5a9f12BFcA13980cB
        });
    }

    /// @notice Devnet addresses
    function _getDevnetHoneyAddresses() private pure returns (HoneyAddresses memory) {
        return HoneyAddresses({
            honey: 0x4475bdcd6F2Ded26Ea5074beb862271f2141f696,
            honeyImpl: 0x4D4Ff71C50D47a5A45682F42E1E96bdED8fE7516,
            honeyFactory: 0x2AA7F988284fD04cE83b27d017B89731c67d8F67,
            honeyFactoryReader: 0xf1CF3467C9508dfa6D1197F5359419856B3A3300,
            honeyFactoryImpl: 0xd6E9728eefa526F9B6Cf3c9ba5CbC060F937cDb0,
            honeyFactoryReaderImpl: 0x52d5848Ab7A304369cd2879DAfd9Ed3349E8ebB1,
            collateralVaultImpl: 0x5DeDB0F5587F83798245a53189c1A52437A52475,
            honeyFactoryPythWrapper: 0xA55F4a5D0415bFAaaE8207F77Ab2dc406e7594A2
        });
    }

    /// @notice Anvil addresses
    function _getAnvilHoneyAddresses() private pure returns (HoneyAddresses memory) {
        return HoneyAddresses({
            honey: 0x442130BDb0eC2e76B1804362b9e9c25bCE299959,
            honeyImpl: 0x36a10E516452BD2A80Bd5F421B0bC69eB0dFBca9,
            honeyFactory: 0xeBF958b3b453f76fBE491a7F3ED29e37a509F530,
            honeyFactoryReader: 0x353F8910914a46b3b971d54A131184fB46B8d7f8,
            honeyFactoryImpl: 0x6178832DAC009EDA2e1D97f158cd94545F49c289,
            honeyFactoryReaderImpl: 0x1eD95AF653E0a540fC61AD8d1C7D2C5271855fD5,
            collateralVaultImpl: 0x149C89732A9e83FDf20CA4AB03A94C3b4eb21C46,
            honeyFactoryPythWrapper: 0x0E870Ae0ecff7036A7d34F9c571794C4ce1C3d62
        });
    }
}
